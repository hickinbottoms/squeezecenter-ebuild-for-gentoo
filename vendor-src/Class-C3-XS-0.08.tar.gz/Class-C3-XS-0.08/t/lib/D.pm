package t::lib::D;
use base ('t::lib::A', 't::lib::E');
1;
