package t::lib::C;
use base ('t::lib::A', 't::lib::B');
1;
